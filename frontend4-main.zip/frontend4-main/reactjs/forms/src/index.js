import ReactDOM from 'react-dom/client';
import './index.css';
import ControlledAccessForm2 from './ControlledAccessForm2.js'
import UnControlledAccessForm from './UnControlledAccessForm.js'
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<UnControlledAccessForm />);